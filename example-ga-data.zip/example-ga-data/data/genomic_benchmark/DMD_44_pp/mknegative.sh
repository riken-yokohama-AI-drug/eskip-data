ls negative/* |
while read line
do

name=$(basename $line)

cat $line | fold -w1 | shuf | tr -d '\n' > positive/shuf-${name} 
echo >> positive/shuf-${name} 

done
