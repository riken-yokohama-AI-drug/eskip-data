count=0
while read line
do

echo $((count++))
if [ $((count%2)) -eq 1 ];then
  continue
fi

mv -v train/negative/$line     test/negative/
mv -v train/positive/*${line}* test/positive/

done <<EOF
target_44_Flank50.fasta
target_10_Flank50.fasta
target_6_Flank50.fasta
target_36_Flank50.fasta
target_7_Flank50.fasta
target_58_Flank50.fasta
target_11_Flank50.fasta
target_37_Flank50.fasta
target_61_Flank50.fasta
target_12_Flank50.fasta
target_38_Flank50.fasta
target_62_Flank50.fasta
target_14_Flank50.fasta
target_39_Flank50.fasta
target_63_Flank50.fasta
target_17_Flank50.fasta
target_3_Flank50.fasta
target_64_Flank50.fasta
target_18_Flank50.fasta
target_41_Flank50.fasta
target_65_Flank50.fasta
target_20_Flank50.fasta
target_42_Flank50.fasta
target_66_Flank50.fasta
target_21_Flank50.fasta
target_43_Flank50.fasta
target_68_Flank50.fasta
target_22_Flank50.fasta
target_69_Flank50.fasta
target_23_Flank50.fasta
target_45_Flank50.fasta
target_24_Flank50.fasta
target_46_Flank50.fasta
target_70_Flank50.fasta
target_25_Flank50.fasta
target_47_Flank50.fasta
target_71_Flank50.fasta
target_26_Flank50.fasta
target_48_Flank50.fasta
target_72_Flank50.fasta
target_27_Flank50.fasta
target_49_Flank50.fasta
target_73_Flank50.fasta
target_28_Flank50.fasta
target_4_Flank50.fasta
target_74_Flank50.fasta
target_2_Flank50.fasta
target_52_Flank50.fasta
target_76_Flank50.fasta
target_31_Flank50.fasta
target_53_Flank50.fasta
target_77_Flank50.fasta
target_32_Flank50.fasta
target_54_Flank50.fasta
target_33_Flank50.fasta
target_55_Flank50.fasta
target_8_Flank50.fasta
target_34_Flank50.fasta
target_56_Flank50.fasta
target_9_Flank50.fasta
target_35_Flank50.fasta
target_57_Flank50.fasta
EOF

