predict_target_60_Flank50.fasta_head50.csv,0.08301091939210892
predict_target_19_Flank50.fasta_head50.csv,0.255649209022522
predict_target_5_Flank50.fasta_head50.csv,0.2672961950302124
predict_target_15_Flank50.fasta_head50.csv,0.2949298322200775
predict_target_13_Flank50.fasta_head50.csv,0.45483461022377014


16,29,30,40,50,51,59,67,75,78,5,13,15,19,60
